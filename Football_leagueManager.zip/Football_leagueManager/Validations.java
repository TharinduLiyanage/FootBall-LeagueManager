import java.util.Scanner;

public class Validations
{
    static Scanner inputValidator = new Scanner(System.in);


    public static boolean checkAdiabatic(String string)
    {
        string = string.toLowerCase();
        char[] charactersArray = string.toCharArray();
        char[] var2 = charactersArray;
        int var3 = charactersArray.length;

        for (int var4 = 0; var4 < var3; ++var4) {
            char ch = var2[var4];
            if (ch < 'a' || ch > 'z') {
                return false;
            }
        }
        return true;
    }

    public String getAlphabetic(String inputMessage, String errorMessage) {
        String input = "";

        while (true) {
            System.out.print(inputMessage);
            input = inputValidator.next();
            if (checkAdiabatic(input)) {
                return input;
            }
            else {
                System.out.println(errorMessage);
            }
        }
    }

    public static boolean isInteger(String userInput) {
        try {
            Integer number = Integer.parseInt(userInput);
            return true;
        } catch (Exception var2) {
            return false;
        }
    }

    public Integer getIntegerInput(String inputMessage, String errorMassage)
    {
        while (true)
        {
            System.out.print(inputMessage);
            String userInput = inputValidator.next();
            if (isInteger(userInput))
            {
                return Integer.parseInt(userInput);
            }
            System.out.print(errorMassage);
        }
    }

    public  static boolean checkRegNO(Integer regNo)
    {


        for(SportClub sportClub : PremierLeagueManager.allClubs)
        {
            if(sportClub.getRegistrationNum()==regNo)
            {
                return false;
            }
        }
        return true;
    }

    public int getRegNO(String inputMessage, String errorMessage1, String errorMessage2)
    {
        while (true)
        {
            System.out.print(inputMessage);
            String userInput = inputValidator.next();
            if (!isInteger(userInput))
            {
                System.out.println(errorMessage2);
            }
            else if (!checkRegNO(Integer.parseInt(userInput)))
            {
                System.out.println(errorMessage1);
            }
            else
            {
                return Integer.parseInt(userInput);
            }
        }
    }

    public int checkDate(String inputMessage, String errorMessage1, String errorMessage2)
    {
        while (true)
        {

            System.out.print(inputMessage);
            String userInput = inputValidator.next();

            if (!isInteger(userInput))
            {
                System.out.println(errorMessage1);
            }

            else if (Integer.parseInt(userInput)<0 || Integer.parseInt(userInput)>31)
            {
                System.out.println(errorMessage2);
            }
            else
            {
                return Integer.parseInt(userInput);
            }
        }
    }

    public int checkMonth(String inputMessage, String errorMessage1, String errorMessage2) {
        while (true) {

            System.out.print(inputMessage);
            String userInput = inputValidator.next();

            if (!isInteger(userInput)) {
                System.out.println(errorMessage1);
            } else if (Integer.parseInt(userInput) < 0 || Integer.parseInt(userInput) > 13) {
                System.out.println(errorMessage2);
            } else {
                return Integer.parseInt(userInput);
            }
        }
    }

    public int checkYear (String inputMessage, String errorMessage1, String errorMessage2)
    {
        while (true) {

            System.out.print(inputMessage);
            String userInput = inputValidator.next();

            if (!isInteger(userInput))
            {
                System.out.println(errorMessage1);
            } else if (Integer.parseInt(userInput) < 2019 || Integer.parseInt(userInput) > 2022)
            {
                System.out.println(errorMessage2);
            } else
            {
                return Integer.parseInt(userInput);
            }
        }


    }

    public  static boolean checkRegNOExists(Integer regNo)
    {


        for(FootballClub footballClub : PremierLeagueManager.premierLeagueClubs)
        {
            if(footballClub.getRegistrationNum()==regNo)
            {
                return true;
            }
        }
        return false;
    }

    public int getValidRegNO(String inputMessage, String errorMessage1, String errorMessage2)
    {
        while (true)
        {
            System.out.print(inputMessage);
            String userInput = inputValidator.next();
            if (!isInteger(userInput))
            {
                System.out.println(errorMessage2);
            }
            else if (!checkRegNOExists(Integer.parseInt(userInput)))
            {
                System.out.println(errorMessage1);
            }
            else
            {
                return Integer.parseInt(userInput);
            }
        }
    }


}



