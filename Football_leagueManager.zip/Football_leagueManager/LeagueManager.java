import java.io.IOException;

public interface LeagueManager
{
    // limiting the number of premier league clubs to 20
    static final int premierLeagueClub=20;
    void addNewFootballCLub(FootballClub footballClub) ;
    void deleteClubFromThePremierLeague(int regNo) ;
    void statisticsForaSelectedClub(int regNo) ;
    void displayThePremierLeagueTable() ;
    void matchUpdate(int teamOne,int teamTwo) ;
    void loadData() throws IOException;
    void saveData()throws IOException;
}
