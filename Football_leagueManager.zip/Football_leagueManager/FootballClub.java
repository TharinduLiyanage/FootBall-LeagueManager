import java.io.Serializable;

public class FootballClub extends SportClub implements Serializable {

    private int numberOfWins;
    private int numberOfDraws;
    private int numberOfDefeats;
    private int numberOfGoalsReceived;
    private int numberOfGoalsScored;
    private int numberOfPoints;
    private int numberOfMatchesPlayed;
    private int goalDifference;
    private int day;
    private int month;
    private int year;


    //constructor to add Professional Development League
    public FootballClub() {
    }
  //constructor to add Basic Information of clubs
    public FootballClub(String clubName, String clubLocation, int registrationNum, int contactNum)
    {
        super(clubName, clubLocation, registrationNum, contactNum);
    }

    public FootballClub(int registrationNum, String clubName, int numberOfMatchesPlayed, int numberOfWins, int numberOfPoints, int numberOfGoalsScored, int numberOfGoalsReceived, int numberOfDraws, int numberOfDefeats) {
        super(clubName, registrationNum);
        this.numberOfMatchesPlayed=numberOfMatchesPlayed;
        this.numberOfWins = numberOfWins;
        this.numberOfDraws = numberOfDraws;
        this.numberOfDefeats = numberOfDefeats;
        this.numberOfGoalsScored = numberOfGoalsScored;
        this.numberOfGoalsReceived = numberOfGoalsReceived;
        this.numberOfPoints = numberOfPoints;

    }

//

    public int getGoalDifference() {
        return goalDifference;
    }

    public void setGoalDifference(int goalDifference) {
        this.goalDifference = goalDifference;
    }

    public int getNumberOfWins() {
        return numberOfWins;
    }

    public void setNumberOfWins(int numberOfWins) {
        this.numberOfWins = numberOfWins;
    }

    public int getNumberOfDraws() {
        return numberOfDraws;
    }

    public void setNumberOfDraws(int numberOfDraws) {
        this.numberOfDraws = numberOfDraws;
    }

    public int getNumberOfDefeats() {
        return numberOfDefeats;
    }

    public void setNumberOfDefeats(int numberOfDefeats) {
        this.numberOfDefeats = numberOfDefeats;
    }

    public int getNumberOfGoalsReceived() {
        return numberOfGoalsReceived;
    }

    public void setNumberOfGoalsReceived(int numberOfGoalsReceived) {
        this.numberOfGoalsReceived = numberOfGoalsReceived;
    }

    public int getNumberOfGoalsScored() {
        return numberOfGoalsScored;
    }

    public void setNumberOfGoalsScored(int numberOfGoalsScored) {
        this.numberOfGoalsScored = numberOfGoalsScored;
    }

    public int getNumberOfPoints() {
        return numberOfPoints;
    }

    public void setNumberOfPoints(int numberOfPoints) {
        this.numberOfPoints = numberOfPoints;
    }

    public int getNumberOfMatchesPlayed() {
        return numberOfMatchesPlayed;
    }

    public void setNumberOfMatchesPlayed(int numberOfMatchesPlayed) {
        this.numberOfMatchesPlayed = numberOfMatchesPlayed;
    }
    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDate()
    {
        String date =  (this.day + "/" + this.month+ "/" + this.year);
        return date;

    }





}
