import java.io.*;
import java.util.ArrayList;


public class PremierLeagueManager implements LeagueManager , Serializable {
    //Array List for add premierLeague clubs
    public static ArrayList<FootballClub> premierLeagueClubs = new ArrayList<>(premierLeagueClub);
    //Array List for add both league clubs
    public static ArrayList<SportClub> allClubs = new ArrayList<>();
    //Array List for add both Match information clubs
    static ArrayList<MatchInfo> matchInfos = new ArrayList<>();
    FootballClubTables footballClubTables = new FootballClubTables();
    static Validations validations =new Validations();


    @Override
    //adding clubs to Football club
    public void addNewFootballCLub(FootballClub footballClub)  {

    //Print club type by user selection
        String clubType;
        if (footballClub instanceof UniversityFootballClub )
        {
            allClubs.add(footballClub);
            clubType = "University Football Club";
        }
        else if(footballClub instanceof SchoolFootballClub)

        {
            allClubs.add(footballClub);
            clubType = "School Football Club";
        }
        else
        {
            premierLeagueClubs.add(footballClub);
            allClubs.add(footballClub);
            clubType = " Football Club";
        }

        System.out.println("\n************** "+clubType+" SuccessFully Added **************\n");


    }

    @Override
    //deleting club by reg no
    public void deleteClubFromThePremierLeague( int regNo)  {

        //for check regno found
        boolean found = false;
        for (SportClub club : allClubs) {
            if (regNo==(club.getRegistrationNum())) {
                found = true;
                String deletedClub;
                if (club instanceof SchoolFootballClub) {
                    deletedClub = "School Football Club";

                } else if (club instanceof UniversityFootballClub) {
                    deletedClub = "University Football Club";

                } else {
                    deletedClub = "Premier League Club";
                    premierLeagueClubs.remove(club);

                }
                allClubs.remove(club);

                System.out.println("\n************** " + regNo + " SuccessFully Deleted from " + deletedClub + " ************** \n");
                break;
            }

        }
        if (!found) {
            System.out.println("\n****************** Club not found [Check the Table] ******************\n");
        }
    }

    @Override
    //display statistics for entered reg no
    public void statisticsForaSelectedClub(int regNo) {

        boolean found = false;
        for (FootballClub scores : premierLeagueClubs)
        {
            if (regNo==(scores.getRegistrationNum()))
            {
                found=true;
                FootballClubTables.header();
                FootballClubTables.getData(scores);
                break;
            }
        }
        if(!found)
        {
            System.out.println("\n************ Club not found *************\n");
        }
    }
    @Override

    //display premier league table by sort according to points
    public void displayThePremierLeagueTable()
    {
        for(int i=0;i<premierLeagueClubs.size();i++)
        {
            for (int j=0;j<premierLeagueClubs.size()-1-i;j++){
                if(premierLeagueClubs.get(j).getNumberOfPoints()==premierLeagueClubs.get(j+1).getNumberOfPoints())
                {
                    if(premierLeagueClubs.get(j).getGoalDifference()< premierLeagueClubs.get(j+1).getGoalDifference()){
                        FootballClub footBallClub = premierLeagueClubs.get(j);
                        premierLeagueClubs.set(j, premierLeagueClubs.get(j + 1));
                        premierLeagueClubs.set(j + 1, footBallClub);
                    }

                }
                else {
                    if(premierLeagueClubs.get(j).getNumberOfPoints()< premierLeagueClubs.get(j+1).getNumberOfPoints()){
                        FootballClub footBallClub = premierLeagueClubs.get(j);
                        premierLeagueClubs.set(j, premierLeagueClubs.get(j + 1));
                        premierLeagueClubs.set(j + 1, footBallClub);
                    }
                }
            }
        }

        footballClubTables.premierLeagueScores();
    }

    @Override
    //update a match by user inputs
    public void matchUpdate(int teamOne,int teamTwo)  {

        String teamName1;
        int numberOfGoalsScored1;
        String teamName2;
        int numberOfGoalsScored2;
        int day;
        int month;
        int year;
        int numberOfPoints1=0;
        int numberOfPoints2=0;
        String date;

        boolean found1 = false;
        boolean found2 = false;

        FootballClub footballClub1 = null;
        FootballClub footballClub2 = null;

        for (FootballClub footballClub : premierLeagueClubs) {
            if (teamOne == (footballClub.getRegistrationNum())) {
                found1 = true;
                footballClub1 = footballClub;
            }
        }
        for (FootballClub footballClub : premierLeagueClubs)
        {
            if (teamTwo == (footballClub.getRegistrationNum()))
            {
                found2 = true;
                footballClub2 = footballClub;
            }
            if (found1 == true && found2 == true)
            {
                teamName1=footballClub1.getClubName();
                teamName2=footballClub2.getClubName();
                day = validations.checkDate(
                        "          \nEnter Date : ",
                        "\n****** Invalid Input Type !!! [Integers Only] ******\n ",
                        "\n******Invalid Date ******\n");
                month = validations.checkMonth(
                        "          \nEnter Month :",
                        "\n****** Invalid Input Type !!! [Integers Only] ******\n ",
                        "\n******Invalid Month ******\n");
                year = validations.checkYear(
                        "           \nEnter Year :",
                        "\n****** Invalid Input Type !!! [Integers Only] ******\n ",
                        "\n******Invalid Year ******\n");

                numberOfGoalsScored1 = validations.getIntegerInput(
                        "\nEnter Scored Goals (" + teamName1+ ") : ",
                        "\n****** Invalid Input Type !!! [Integers Only] ******\n ");
                numberOfGoalsScored2 = validations.getIntegerInput(
                        "\nEnter Scored Goals (" + teamName2 + ") : ",
                        "\n****** Invalid Input Type !!! [Integers Only] ******\n ");

                if (numberOfGoalsScored1 > numberOfGoalsScored2) {


                    footballClub1.setNumberOfMatchesPlayed(footballClub1.getNumberOfMatchesPlayed() + 1);
                    footballClub1.setNumberOfPoints(footballClub1.getNumberOfPoints() + 3);
                    footballClub1.setNumberOfWins(footballClub1.getNumberOfWins() + 1);
                    footballClub1.setNumberOfGoalsScored(footballClub1.getNumberOfGoalsScored() + numberOfGoalsScored1);
                    footballClub1.setNumberOfGoalsReceived(footballClub1.getNumberOfGoalsReceived() + numberOfGoalsScored2);


                    footballClub2.setNumberOfDefeats(footballClub2.getNumberOfDefeats() + 1);
                    footballClub2.setNumberOfMatchesPlayed(footballClub2.getNumberOfMatchesPlayed() + 1);
                    footballClub2.setNumberOfGoalsScored(footballClub2.getNumberOfGoalsScored() + numberOfGoalsScored2);
                    footballClub2.setNumberOfGoalsReceived(footballClub2.getNumberOfGoalsReceived() + numberOfGoalsScored1);

                    System.out.println("\n *********** team " +  teamName1 + " won the match by " + (numberOfGoalsScored1 - numberOfGoalsScored2) + "scores *******\n");



                }
                else if (numberOfGoalsScored1 < numberOfGoalsScored2)
                {
                    footballClub2.setNumberOfMatchesPlayed(footballClub2.getNumberOfMatchesPlayed() + 1);
                    footballClub2.setNumberOfPoints(footballClub2.getNumberOfPoints() + 3);
                    footballClub2.setNumberOfWins(footballClub2.getNumberOfWins() + 1);
                    footballClub2.setNumberOfGoalsScored(footballClub2.getNumberOfGoalsScored() + numberOfGoalsScored2);
                    footballClub2.setNumberOfGoalsReceived(footballClub2.getNumberOfGoalsReceived() + numberOfGoalsScored1);

                    footballClub1.setNumberOfDefeats(footballClub1.getNumberOfDefeats() + 1);
                    footballClub1.setNumberOfMatchesPlayed(footballClub1.getNumberOfMatchesPlayed() + 1);
                    footballClub1.setNumberOfGoalsScored(footballClub1.getNumberOfGoalsScored() + numberOfGoalsScored1);
                    footballClub1.setNumberOfGoalsReceived(footballClub1.getNumberOfGoalsReceived() + numberOfGoalsScored2);

                    System.out.println("\n *********** team " + teamTwo + " won the match by " + (numberOfGoalsScored2 - numberOfGoalsScored1) + " GOALS *******\n");

                }
                else
                {
                    footballClub1.setNumberOfPoints(footballClub1.getNumberOfPoints() + 1);
                    footballClub1.setNumberOfDraws(footballClub1.getNumberOfDraws()+1);
                    footballClub1.setNumberOfGoalsScored(footballClub1.getNumberOfGoalsScored()+numberOfGoalsScored1);
                    footballClub1.setNumberOfMatchesPlayed(footballClub1.getNumberOfMatchesPlayed()+ 1);
                    footballClub1.setNumberOfGoalsReceived(footballClub1.getNumberOfGoalsReceived()+numberOfGoalsScored2);

                    footballClub2.setNumberOfPoints(footballClub2.getNumberOfPoints() + 1);
                    footballClub2.setNumberOfDraws(footballClub2.getNumberOfDraws()+1);
                    footballClub2.setNumberOfGoalsScored(footballClub2.getNumberOfGoalsScored()+numberOfGoalsScored2);
                    footballClub2.setNumberOfGoalsReceived(footballClub2.getNumberOfGoalsReceived()+numberOfGoalsScored1);
                    footballClub2.setNumberOfMatchesPlayed(footballClub2.getNumberOfMatchesPlayed()+ 1);

                    System.out.println("\n************ DRAW ************\n");
                }

                date = day+"/"+month+"/"+year;

                footballClub1.setDay(day);
                footballClub1.setMonth(month);
                footballClub1.setYear(year);

                footballClub2.setDay(day);
                footballClub2.setMonth(month);
                footballClub2.setYear(year);

                MatchInfo match = new MatchInfo(date,teamOne,teamName1,numberOfGoalsScored1,numberOfPoints1,teamTwo,teamName2,numberOfGoalsScored2,numberOfPoints2,day,month,year);
                matchInfos.add(match);

                break;

            }
        }
    }


//create  to pass the array list
    public ArrayList<FootballClub> getPremierLeagueClubs() { return this.premierLeagueClubs; }
    public ArrayList<MatchInfo>getPremierLeagueMatches () { return this.matchInfos; }

    public void saveData ()
    {
        //save data to the file
        try {
            FileOutputStream fileOut = new FileOutputStream("footballCLubManagerData.txt");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);

            for (SportClub sportClub : allClubs )
            {
                objectOut.writeObject(sportClub);
            }

            fileOut.flush();
            objectOut.close();
            fileOut.close();


        } catch (IOException i)
        {
            i.printStackTrace();

        }



        try
        {
            FileOutputStream fileOut2 = new FileOutputStream("premierLeagueManagerData.txt");
            ObjectOutputStream objectOut2 = new ObjectOutputStream(fileOut2);

            for (FootballClub footballClub : premierLeagueClubs )
            {
                objectOut2.writeObject(footballClub);
            }
            fileOut2.flush();
            objectOut2.close();
            fileOut2.close();

        } catch (IOException i) {
            i.printStackTrace();
        }

        try
        {
            FileOutputStream fileOut3 = new FileOutputStream("premierLeagueMatchData.txt");
            ObjectOutputStream objectOut3 = new ObjectOutputStream(fileOut3);

            for (MatchInfo matchInfo : matchInfos )
            {
                objectOut3.writeObject(matchInfo);
            }
            fileOut3.flush();
            objectOut3.close();
            fileOut3.close();
            System.out.println("\n **** Club details added successfully ! ****");

        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public void loadData() throws IOException
    {
        //lod data from file to arrayList

        FileInputStream fileInputStream = new FileInputStream("footballCLubManagerData.txt");
        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);

        for (; ; )
        {
            try
            {
                SportClub sportClub = (SportClub) objectInputStream.readObject();

                allClubs.add(sportClub);

            } catch (Exception e)
            {
                break;
            }
        }
        fileInputStream.close();
        objectInputStream.close();

        FileInputStream fileInputStream2 = new FileInputStream("premierLeagueManagerData.txt");
        ObjectInputStream objectInputStream2=new ObjectInputStream(fileInputStream2);

        for (; ; )
        {
            try
            {

                FootballClub footballClub = (FootballClub) objectInputStream2.readObject();

                premierLeagueClubs.add(footballClub);

            } catch (Exception e)
            {

                break;
            }

        }
        fileInputStream2.close();
        objectInputStream2.close();


        FileInputStream fileInputStream3 = new FileInputStream("premierLeagueMatchData.txt");
        ObjectInputStream objectInputStream3 = new ObjectInputStream(fileInputStream3);

        for (; ; )
        {
            try
            {
                MatchInfo matchInfo = (MatchInfo) objectInputStream3.readObject();

                matchInfos.add(matchInfo);

            } catch (Exception e)
            {
                break;
            }
        }
        fileInputStream3.close();
        objectInputStream3.close();
    }
    private static PremierLeagueManager premierLeagueManager = null;

    public PremierLeagueManager() {
    }

    public static PremierLeagueManager getObj() {
        if (premierLeagueManager == null) {
            synchronized (PremierLeagueManager.class) {
                premierLeagueManager = new PremierLeagueManager();
            }
        }
        return premierLeagueManager;
    }

}

