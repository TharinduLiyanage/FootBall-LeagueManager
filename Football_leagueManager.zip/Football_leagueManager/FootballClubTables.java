import static java.lang.String.valueOf;

public class FootballClubTables
{
//methode for display all clubs in football club
    public void showAllClubs()
    {
        sortTable();

        String registrationNum = "Registration No";
        String clubName = "Club Name";
        String clubType = "Club Type";
        System.out.println("---------------------------------------------------------------------------------------");
        System.out.printf("| %-30s| %-30s| %-20s|\n", registrationNum, clubName, clubType);
        System.out.println("---------------------------------------------------------------------------------------");

        for (SportClub sportClub: PremierLeagueManager.allClubs )
        {
            registrationNum = valueOf(sportClub.getRegistrationNum());
            clubName = sportClub.getClubName();
            if (sportClub instanceof UniversityFootballClub) {
                clubType = "University club";
            } else if (sportClub instanceof SchoolFootballClub) {
                clubType = "School club";
            } else {
                clubType = "Premier league";
            }
            System.out.printf("| %-30s| %-30s| %-20s|\n", registrationNum, clubName, clubType);
            System.out.println("---------------------------------------------------------------------------------------");
        }

    }
//methode for display only premier league clubs
    public void showPremierLeagueClubs() {

        String[] score = new String[PremierLeagueManager.premierLeagueClubs.size()];

        for (int i = 0; i < PremierLeagueManager.premierLeagueClubs.size(); i++) {
            score[i] = valueOf(PremierLeagueManager.premierLeagueClubs.get(i).getRegistrationNum());
        }

        for (int i = 0; i < PremierLeagueManager.premierLeagueClubs.size(); i++) {
            for (int j = 0; j < PremierLeagueManager.premierLeagueClubs.size() - 1 - i; j++) {
                if (score[j].compareTo(score[j + 1]) > 0) {
                    String points = score[j];
                    score[j] = score[j + 1];
                    score[j + 1] = points;

                    FootballClub footballClub = PremierLeagueManager.premierLeagueClubs.get(j);
                    PremierLeagueManager.premierLeagueClubs.set(j, PremierLeagueManager.premierLeagueClubs.get(j + 1));
                    PremierLeagueManager.premierLeagueClubs.set(j + 1, footballClub);
                }
            }
        }


        String registrationNum = "Registration No";
        String clubName = "Club Name";

        System.out.println("-------------------------------------");
        System.out.printf("| %-15s | %-15s |\n", registrationNum, clubName);
        System.out.println("-------------------------------------");
        for (FootballClub footballClub : PremierLeagueManager.premierLeagueClubs) {
            registrationNum = valueOf(footballClub.getRegistrationNum());
            clubName = footballClub.getClubName();

            System.out.printf("| %-15s | %-15s |\n", registrationNum, clubName);
            System.out.println("-------------------------------------");
        }
    }



    public void premierLeagueScores()
    {
        header();

        for (FootballClub footballClub : PremierLeagueManager.premierLeagueClubs)
        {
            getData(footballClub);

        }

    }

    public static void header() {
        String registrationNum = "Registration No";
        String clubName = "Club Name";
        String matches = " Played Matches";
        String points = "Points";
        String wins = "Wins";
        String goalsScored = "Scored";
        String goalsReceived = "Received";
        String draws = "Draws";
        String defeats = "Defeats";
        String date="Last Update";
        System.out.println("\n-------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("| %-15s | %-15s | %-15s | %-10s | %-10s | %-10s | %-10s | %-10s | %-10s| %-10s|\n", registrationNum, clubName, matches, points, wins, goalsScored, goalsReceived, draws, defeats,date);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------");
    }

    public static void getData(FootballClub footballClub)
    {
        String registrationNum;
        String clubName;
        String matches;
        String points;
        String wins;
        String goalsScored;
        String goalsReceived;
        String draws;
        String defeats;
        String date;
        registrationNum = valueOf(footballClub.getRegistrationNum());
        clubName = valueOf(footballClub.getClubName());
        matches = valueOf(footballClub.getNumberOfMatchesPlayed());
        points = valueOf(footballClub.getNumberOfPoints());
        wins = valueOf(footballClub.getNumberOfWins());
        goalsScored = valueOf(footballClub.getNumberOfGoalsScored());
        goalsReceived = valueOf(footballClub.getNumberOfGoalsReceived());
        draws = valueOf(footballClub.getNumberOfDraws());
        defeats = valueOf(footballClub.getNumberOfDefeats());
        date= footballClub.getDate();

        System.out.printf("| %-15s | %-15s | %-15s | %-10s | %-10s | %-10s | %-10s | %-10s | %-10s| %-10s |\n", registrationNum, clubName, matches, points, wins, goalsScored, goalsReceived, draws, defeats,date);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------");
    }

    public void sortTable(){
        String[] score = new String[PremierLeagueManager.allClubs.size()];

        for (int i = 0; i < PremierLeagueManager.allClubs.size(); i++) {
            score[i] = valueOf(PremierLeagueManager.allClubs.get(i).getRegistrationNum());
        }

        for (int i = 0; i < PremierLeagueManager.allClubs.size(); i++) {
            for (int j = 0; j < PremierLeagueManager.allClubs.size() - 1 - i; j++) {
                if (score[j].compareTo(score[j + 1]) > 0) {
                    String points = score[j];
                    score[j] = score[j + 1];
                    score[j + 1] = points;

                    SportClub sportClub = PremierLeagueManager.allClubs.get(j);
                    PremierLeagueManager.allClubs.set(j, PremierLeagueManager.allClubs.get(j + 1));
                    PremierLeagueManager.allClubs.set(j + 1, sportClub);
                }
            }
        }

    }



}



