import java.io.Serializable;
import java.util.Objects;

public class UniversityFootballClub extends FootballClub implements Serializable {

    String nameOfTheUniversity;
    String nameOfTheFaculty;


    public UniversityFootballClub(String clubName, String clubLocation, int registrationNum, int contactNum, String nameOfTheUniversity, String nameOfTheFaculty) {
        super(clubName, clubLocation, registrationNum, contactNum);
        this.nameOfTheUniversity = nameOfTheUniversity;
        this.nameOfTheFaculty = nameOfTheFaculty;
    }

    public String getNameOfTheUniversity() {
        return nameOfTheUniversity;
    }

    public void setNameOfTheUniversity(String nameOfTheUniversity) {
        this.nameOfTheUniversity = nameOfTheUniversity;
    }

    public String getNameOfTheFaculty() {
        return nameOfTheFaculty;
    }

    public void setNameOfTheFaculty(String nameOfTheFaculty) {
        this.nameOfTheFaculty = nameOfTheFaculty;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        UniversityFootballClub that = (UniversityFootballClub) o;
        return nameOfTheFaculty.equals(that.nameOfTheFaculty);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), nameOfTheFaculty);
    }
}


