import java.io.Serializable;
import java.util.Objects;

public class SportClub implements Serializable {

    private String clubName;
    private String clubLocation;
    private int registrationNum;
    private int contactNum;

    public SportClub() {
    }

    public SportClub(String clubName, String clubLocation, int registrationNum, int contactNum) {
        this.clubName = clubName;
        this.clubLocation = clubLocation;
        this.registrationNum = registrationNum;
        this.contactNum = contactNum;
    }

    public SportClub(String clubName, int registrationNum) {
        this.clubName = clubName;
        this.registrationNum = registrationNum;
    }


    public String getClubName() {
        return clubName;
    }

    public void setClubName(String clubName) {
        this.clubName = clubName;
    }

    public String getClubLocation() {
        return clubLocation;
    }

    public void setClubLocation(String clubLocation) {
        this.clubLocation = clubLocation;
    }

    public  int getRegistrationNum() {
        return registrationNum;
    }

    public void setRegistrationNum(int registrationNum) {
        registrationNum = registrationNum;
    }

    public int getContactNum() {
        return contactNum;
    }

    public void setContactNum(int contactNum) {
        this.contactNum = contactNum;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SportClub sportClub = (SportClub) o;
        return registrationNum == sportClub.registrationNum;
    }

    @Override
    public int hashCode() {
        return Objects.hash(registrationNum);
    }


}

