import java.io.Serializable;

//to save match details

public class MatchInfo implements Serializable {
    private String date;
    int day;
    int month;
    int year;
    private int numberOfGoalsScored1;
    private int numberOfPoints1;
    private  int teamRegNo1;
    private String teamName1;
    private  int teamRegNo2;
    private String teamName2;
    private int numberOfGoalsScored2;
    private int numberOfPoints2;

    public MatchInfo(String date, int teamRegNo1,
                     String teamName1, int numberOfGoalsScored1, int numberOfPoints1 , int teamRegNo2, String teamName2, int numberOfGoalsScored2,
                     int numberOfPoints2, int day, int month, int year) {
        this.date = date;
        this.numberOfGoalsScored1 = numberOfGoalsScored1;
        this.numberOfPoints1 = numberOfPoints1;
        this.teamRegNo1 = teamRegNo1;
        this.teamName1 = teamName1;
        this.teamRegNo2 = teamRegNo2;
        this.teamName2 = teamName2;
        this.numberOfGoalsScored2 = numberOfGoalsScored2;
        this.numberOfPoints2 = numberOfPoints2;
        this.day=day;
        this.month=month;
        this.year=year;
    }


    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getNumberOfGoalsScored1() {
        return numberOfGoalsScored1;
    }

    public void setNumberOfGoalsScored1(int numberOfGoalsScored1) {
        this.numberOfGoalsScored1 = numberOfGoalsScored1;
    }

    public int getNumberOfPoints1() {
        return numberOfPoints1;
    }

    public void setNumberOfPoints1(int numberOfPoints1) {
        this.numberOfPoints1 = numberOfPoints1;
    }

    public int getTeamRegNo1() {
        return teamRegNo1;
    }

    public void setTeamRegNo1(int teamRegNo1) {
        this.teamRegNo1 = teamRegNo1;
    }

    public String getTeamName1() {
        return teamName1;
    }

    public void setTeamName1(String teamName1) {
        this.teamName1 = teamName1;
    }

    public int getTeamRegNo2() {
        return teamRegNo2;
    }

    public void setTeamRegNo2(int teamRegNo2) {
        this.teamRegNo2 = teamRegNo2;
    }

    public String getTeamName2() {
        return teamName2;
    }

    public void setTeamName2(String teamName2) {
        this.teamName2 = teamName2;
    }

    public int getNumberOfGoalsScored2() {
        return numberOfGoalsScored2;
    }

    public void setNumberOfGoalsScored2(int numberOfGoalsScored2) {
        this.numberOfGoalsScored2 = numberOfGoalsScored2;
    }

    public int getNumberOfPoints2() {
        return numberOfPoints2;
    }

    public void setNumberOfPoints2(int numberOfPoints2) {
        this.numberOfPoints2 = numberOfPoints2;
    }

    @Override
    public String toString() {
        return "Match{" +
                "date='" + date + '\'' +
                ", numberOfGoalsScored1=" + numberOfGoalsScored1 +
                ", numberOfPoints1=" + numberOfPoints1 +
                ", teamRegNo1=" + teamRegNo1 +
                ", teamName1='" + teamName1 + '\'' +
                ", teamRegNo2=" + teamRegNo2 +
                ", teamName2='" + teamName2 + '\'' +
                ", numberOfGoalsScored2=" + numberOfGoalsScored2 +
                ", numberOfPoints2=" + numberOfPoints2 +
                '}';
    }
}

