import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.Random;


public class PremierLeague_GUI
{
    public void getPremierLeagueGUI(PremierLeagueManager premierLeagueManager)
    {
        Stage stage = new Stage();
        ArrayList<FootballClub>premierLeagueClubs=premierLeagueManager.getPremierLeagueClubs();
        ArrayList<MatchInfo>matchInfos=premierLeagueManager.getPremierLeagueMatches();



        Pane clubInfo = new Pane();
        Button btnClubs = new Button("All Clubs");
        btnClubs.setLayoutX(22);btnClubs.setLayoutY(99);
        btnClubs.setPrefSize(181,78);
        btnClubs.setStyle("-fx-background-color:#ccffff ;-fx-cursor:hand;-fx-font-size: 20;");

        btnClubs.setOnMouseEntered(event -> {
            btnClubs.setStyle("-fx-border-color: black;-fx-cursor:hand;-fx-font-size: 25;");
        });
        btnClubs.setOnMouseExited(event -> {
            btnClubs.setStyle("-fx-background-color:#ccffff ;-fx-cursor:hand;-fx-font-size: 20;");
        });

        btnClubs.setOnAction(event ->
        {

            Integer[] clubMembers = new Integer[premierLeagueClubs.size()];
            if(premierLeagueClubs.size()==0)
            {
                Alert emptyClubs = new Alert(Alert.AlertType.ERROR, "NO clubs to display !!!", ButtonType.OK);
                emptyClubs.show();
            }
            else
                {
                for (int i = 0; i < premierLeagueClubs.size(); i++) {
                    clubMembers[i] = premierLeagueClubs.get(i).getNumberOfPoints();
                }
                for (int i = 0; i < premierLeagueClubs.size(); i++) {
                    for (int j = 0; j < premierLeagueClubs.size() - 1 - i; j++) {
                        if (clubMembers[j].compareTo(clubMembers[j + 1]) < 0) {
                            int points = clubMembers[j];
                            clubMembers[j] = clubMembers[j + 1];
                            clubMembers[j + 1] = points;

                            FootballClub footballClub = premierLeagueClubs.get(j);
                            premierLeagueClubs.set(j, premierLeagueClubs.get(j + 1));
                            premierLeagueClubs.set(j + 1, footballClub);
                        }
                    }
                    clubTable(clubInfo);
                }
            }

        });
        Button btnMatch = new Button("Played Matches");
        btnMatch.setLayoutX(232);btnMatch.setLayoutY(99);
        btnMatch.setPrefSize(160,78);
        btnMatch.setStyle("-fx-background-color:#ccffff ;-fx-cursor:hand;-fx-font-size: 15;");

        btnMatch.setOnMouseEntered(event -> {
            btnMatch.setStyle("-fx-border-color: black;-fx-cursor:hand;-fx-font-size: 20;");
        });
        btnMatch.setOnMouseExited(event -> {
            btnMatch.setStyle("-fx-background-color:#ccffff ;-fx-cursor:hand;-fx-font-size: 15;");
        });

        btnMatch.setOnAction(event ->
                matchTable(clubInfo));


        TextField txtSearch = new TextField();
        txtSearch.setPrefSize(238,25);
        txtSearch.setLayoutX(695);txtSearch.setLayoutY(36);



        Button btnSearch =  new Button("Search");
        btnSearch.setLayoutX(935.0);btnSearch.setLayoutY(36);
        btnSearch.setPrefSize(74,3);
        btnSearch.setStyle("-fx-background-color:#ccffff ;-fx-cursor:hand;");

        btnSearch.setOnMouseEntered(event -> {
            btnSearch.setStyle("-fx-border-color: black;-fx-cursor:hand;-fx-font-size: 15;");
        });
        btnSearch.setOnMouseExited(event -> {
            btnSearch.setStyle("-fx-background-color:#ccffff ;-fx-cursor:hand;");
        });
        btnSearch.setOnAction(event ->
        {
            Boolean found= false ;

            if(txtSearch.getText().isEmpty())
            {
                Alert emptyText = new Alert(Alert.AlertType.ERROR, "NO VALUES ENTERED !!!", ButtonType.OK);
                emptyText.show();
                txtSearch.clear();
            }
            else
                {

                    for(int s = 0; s < matchInfos.size(); s++)
                    {
                        if(txtSearch.getText().equalsIgnoreCase(matchInfos.get(s).getDate()))
                        {
                            String date = txtSearch.getText();
                            int numberOfGoalsScored1=matchInfos.get(s).getNumberOfGoalsScored1();
                            int numberOfPoints1=matchInfos.get(s).getNumberOfPoints1();
                            int teamRegNo1=matchInfos.get(s).getTeamRegNo1();
                            String teamName1=matchInfos.get(s).getTeamName1();
                            int teamRegNo2=matchInfos.get(s).getTeamRegNo2();
                            String teamName2=matchInfos.get(s).getTeamName2();
                            int numberOfGoalsScored2=matchInfos.get(s).getNumberOfGoalsScored2();
                            int numberOfPoints2=matchInfos.get(s).getNumberOfPoints2();
                            int day=0;
                            int month=0;
                            int year=0;

                            TableView premierLeagueTable2 = new TableView();
                            premierLeagueTable2.setLayoutX(40);
                            premierLeagueTable2.setLayoutY(260);
                            premierLeagueTable2.setPrefSize(1000,307.0);

                            TableColumn column1 = new TableColumn("Date");
                            column1.setCellValueFactory(new PropertyValueFactory("date"));
                            column1.setPrefWidth(136);

                            TableColumn<String, MatchInfo> column2 = new TableColumn<>("TeamOne RegNO  ");
                            column2.setCellValueFactory(new PropertyValueFactory<>("teamRegNo1"));
                            column2.setPrefWidth(136);

                            TableColumn<String, MatchInfo> column3 = new TableColumn<>("TeamOne Name");
                            column3.setCellValueFactory(new PropertyValueFactory<>("teamName1"));
                            column3.setPrefWidth(136);

                            TableColumn<String, MatchInfo> column4 = new TableColumn<>("TeamOne Goals");
                            column4.setCellValueFactory(new PropertyValueFactory<>("numberOfGoalsScored1"));
                            column4.setPrefWidth(136);

                            TableColumn<String, MatchInfo> column6 = new TableColumn<>("TeamTwo RegNO");
                            column6.setCellValueFactory(new PropertyValueFactory<>("teamRegNo2"));
                            column6.setPrefWidth(136);

                            TableColumn column7 = new TableColumn("TeamTwo Name");
                            column7.setCellValueFactory(new PropertyValueFactory("teamName2"));
                            column7.setPrefWidth(136);

                            TableColumn<String, MatchInfo> column8 = new TableColumn<>("TeamTwo Goals");
                            column8.setCellValueFactory(new PropertyValueFactory<>("numberOfGoalsScored2"));
                            column8.setPrefWidth(136);

                            premierLeagueTable2.getColumns().addAll(column1,column2,column3,column4,column6,column7,column8);

                            premierLeagueTable2.getItems().add(new MatchInfo(date,teamRegNo1,teamName1,numberOfGoalsScored1,numberOfPoints1,teamRegNo2,teamName2,numberOfGoalsScored2,numberOfPoints2,day,month,year));

                            clubInfo.getChildren().addAll(premierLeagueTable2);

                            found=true;

                        }
                    }
                    if(!found)
                    {
                        Alert notFound = new Alert(Alert.AlertType.WARNING, "Searched Not Found !! ", ButtonType.OK);
                        notFound.show();
                        txtSearch.clear();
                    }

                }

        });

        Button btnMatchGenerate = new Button("Match Generator");
        btnMatchGenerate.setLayoutX(470);
        btnMatchGenerate.setLayoutY(68);
        btnMatchGenerate.setPrefSize(180,140);
        btnMatchGenerate.setStyle("-fx-background-radius: 60; -fx-border-radius: 60; -fx-background-color:#ccffff ;-fx-cursor:hand;-fx-font-size: 15;");

        btnMatchGenerate.setOnMouseEntered(event -> {
            btnMatchGenerate.setStyle("-fx-background-radius: 60; -fx-border-radius: 60;-fx-border-color: black;-fx-cursor:hand;-fx-font-size: 20;");
        });
        btnMatchGenerate.setOnMouseExited(event -> {
            btnMatchGenerate.setStyle("-fx-background-radius: 60; -fx-border-radius: 60;-fx-background-color:#ccffff ;-fx-cursor:hand;-fx-font-size: 15;");
        });
        btnMatchGenerate.setOnAction(event ->
        {
            if(premierLeagueClubs.size()<=1)
            {
                Alert emptyClubs = new Alert(Alert.AlertType.ERROR, "NO enough clubs to play a match !!!", ButtonType.OK);
                emptyClubs.show();
            }
            else {
                Random random = new Random();
                int t1 = random.nextInt(premierLeagueClubs.size());
                int t2 = random.nextInt(premierLeagueClubs.size());

                if (t1 == t2)
                {
                    t2 = random.nextInt(premierLeagueClubs.size());
                } else {

                    String teamName1;
                    int numberOfGoalsScored1;
                    String teamName2;
                    int numberOfGoalsScored2;
                    int day;
                    int month;
                    int year = 2021;
                    int numberOfPoints1 = 0;
                    int numberOfPoints2 = 0;
                    String date;

                    int teamOne = premierLeagueClubs.get(t1).getRegistrationNum();
                    int teamTwo = premierLeagueClubs.get(t2).getRegistrationNum();

                    teamName1 = premierLeagueClubs.get(t1).getClubName();
                    teamName2 = premierLeagueClubs.get(t2).getClubName();

                    day = random.nextInt(31) + 1;
                    month = random.nextInt(12) + 1;
                    date = day + "/" + month + "/" + year;
                    numberOfGoalsScored1 = random.nextInt(20);
                    numberOfGoalsScored2 = random.nextInt(20);

                    if (numberOfGoalsScored1 > numberOfGoalsScored2) {
                        premierLeagueClubs.get(t1).setNumberOfWins(premierLeagueClubs.get(t1).getNumberOfWins() + 1);
                        premierLeagueClubs.get(t1).setNumberOfPoints(premierLeagueClubs.get(t1).getNumberOfPoints() + 3);
                        premierLeagueClubs.get(t1).setNumberOfGoalsScored(premierLeagueClubs.get(t1).getNumberOfGoalsScored() + numberOfGoalsScored1);
                        premierLeagueClubs.get(t1).setNumberOfGoalsReceived(premierLeagueClubs.get(t1).getNumberOfGoalsReceived() + numberOfGoalsScored2);
                        premierLeagueClubs.get(t1).setNumberOfMatchesPlayed(premierLeagueClubs.get(t1).getNumberOfMatchesPlayed() + 1);

                        premierLeagueClubs.get(t2).setNumberOfDefeats(premierLeagueClubs.get(t2).getNumberOfDefeats() + 1);
                        premierLeagueClubs.get(t2).setNumberOfGoalsScored(premierLeagueClubs.get(t2).getNumberOfGoalsScored() + numberOfGoalsScored2);
                        premierLeagueClubs.get(t2).setNumberOfGoalsReceived(premierLeagueClubs.get(t2).getNumberOfGoalsReceived() + numberOfGoalsScored1);
                        premierLeagueClubs.get(t2).setNumberOfMatchesPlayed(premierLeagueClubs.get(t2).getNumberOfMatchesPlayed() + 1);

                        Alert win = new Alert(Alert.AlertType.INFORMATION, teamName1 + " Played with " + teamName2 + " on " + date + " & " + teamName1 + " won the match by " + (numberOfGoalsScored1 - numberOfGoalsScored2) + " Goals");
                        win.show();
                    } else if (numberOfGoalsScored1 < numberOfGoalsScored2) {
                        premierLeagueClubs.get(t2).setNumberOfWins(premierLeagueClubs.get(t2).getNumberOfWins() + 1);
                        premierLeagueClubs.get(t2).setNumberOfPoints(premierLeagueClubs.get(t2).getNumberOfPoints() + 3);
                        premierLeagueClubs.get(t2).setNumberOfGoalsScored(premierLeagueClubs.get(t2).getNumberOfGoalsScored() + numberOfGoalsScored2);
                        premierLeagueClubs.get(t2).setNumberOfGoalsReceived(premierLeagueClubs.get(t2).getNumberOfGoalsReceived() + numberOfGoalsScored1);
                        premierLeagueClubs.get(t2).setNumberOfMatchesPlayed(premierLeagueClubs.get(t2).getNumberOfMatchesPlayed() + 1);

                        premierLeagueClubs.get(t1).setNumberOfDefeats(premierLeagueClubs.get(t1).getNumberOfDefeats() + 1);
                        premierLeagueClubs.get(t1).setNumberOfGoalsScored(premierLeagueClubs.get(t1).getNumberOfGoalsScored() + numberOfGoalsScored1);
                        premierLeagueClubs.get(t1).setNumberOfGoalsReceived(premierLeagueClubs.get(t1).getNumberOfGoalsReceived() + numberOfGoalsScored2);
                        premierLeagueClubs.get(t1).setNumberOfMatchesPlayed(premierLeagueClubs.get(t1).getNumberOfMatchesPlayed() + 1);

                        Alert win = new Alert(Alert.AlertType.INFORMATION, teamName1 + " Played with " + teamName2 + " on " + date + " & " + teamName2 + " won the match by " + (numberOfGoalsScored2 - numberOfGoalsScored1) + " Goals");
                        win.show();
                    } else {
                        premierLeagueClubs.get(t1).setNumberOfDraws(premierLeagueClubs.get(t1).getNumberOfDraws() + 1);
                        premierLeagueClubs.get(t2).setNumberOfDraws(premierLeagueClubs.get(t2).getNumberOfDraws() + 1);

                        premierLeagueClubs.get(t1).setNumberOfPoints(premierLeagueClubs.get(t1).getNumberOfPoints() + 1);
                        premierLeagueClubs.get(t1).setNumberOfGoalsScored(premierLeagueClubs.get(t1).getNumberOfGoalsScored() + numberOfGoalsScored1);
                        premierLeagueClubs.get(t1).setNumberOfGoalsReceived(premierLeagueClubs.get(t1).getNumberOfGoalsReceived() + numberOfGoalsScored2);
                        premierLeagueClubs.get(t1).setNumberOfMatchesPlayed(premierLeagueClubs.get(t1).getNumberOfMatchesPlayed() + 1);

                        premierLeagueClubs.get(t2).setNumberOfPoints(premierLeagueClubs.get(t2).getNumberOfPoints() + 1);
                        premierLeagueClubs.get(t2).setNumberOfGoalsScored(premierLeagueClubs.get(t2).getNumberOfGoalsScored() + numberOfGoalsScored2);
                        premierLeagueClubs.get(t2).setNumberOfGoalsReceived(premierLeagueClubs.get(t2).getNumberOfGoalsReceived() + numberOfGoalsScored1);
                        premierLeagueClubs.get(t2).setNumberOfMatchesPlayed(premierLeagueClubs.get(t2).getNumberOfMatchesPlayed() + 1);

                        Alert win = new Alert(Alert.AlertType.INFORMATION, teamName1 + " Played with " + teamName2 + " on " + date + " &  Match Draw");
                        win.show();
                    }

                    premierLeagueClubs.get(t1).setDay(day);
                    premierLeagueClubs.get(t1).setMonth(month);
                    premierLeagueClubs.get(t1).setYear(year);

                    premierLeagueClubs.get(t2).setDay(day);
                    premierLeagueClubs.get(t2).setMonth(month);
                    premierLeagueClubs.get(t2).setYear(year);


                    MatchInfo match = new MatchInfo(date, teamOne, teamName1, numberOfGoalsScored1, numberOfPoints1, teamTwo, teamName2, numberOfGoalsScored2, numberOfPoints2, day, month, year);
                    matchInfos.add(match);

                    matchTable(clubInfo);
                }
            }





        });

        ToggleGroup sortType =new ToggleGroup();

        Button btnSortBYDate = new Button("Sort by Date");
        btnSortBYDate.setLayoutX(739);
        btnSortBYDate.setLayoutY(99);
        btnSortBYDate.setPrefSize(182,34);

        btnSortBYDate.setOnMouseEntered(event -> {
            btnSortBYDate.setStyle("-fx-border-color: black;-fx-cursor:hand ;-fx-font-size: 20;");
        });
        btnSortBYDate.setOnMouseExited(event -> {
            btnSortBYDate.setStyle("-fx-background-color:#ccffff ;-fx-cursor:hand;-fx-font-size: 15;");
        });

        btnSortBYDate.setOnAction(event ->
        {

            for(int i=0;i<matchInfos.size();i++)
            {
                for (int j=0;j<matchInfos.size()-1-i;j++){
                    if(matchInfos.get(j).getYear()==matchInfos.get(j+1).getYear())
                    {
                        if(matchInfos.get(j).getMonth()< matchInfos.get(j+1).getMonth()){
                            MatchInfo matchInfo = matchInfos.get(j);
                            matchInfos.set(j, matchInfos.get(j + 1));
                            matchInfos.set(j + 1, matchInfo);
                        }

                    }
                    else if(matchInfos.get(j).getMonth()==matchInfos.get(j+1).getMonth())
                    {
                        if(matchInfos.get(j).getDay()< matchInfos.get(j+1).getDay()){
                            MatchInfo matchInfo = matchInfos.get(j);
                            matchInfos.set(j, matchInfos.get(j + 1));
                            matchInfos.set(j + 1, matchInfo);
                        }
                    }

                    else
                        {
                            {
                                if(matchInfos.get(j).getYear()< matchInfos.get(j+1).getYear()){
                                    MatchInfo matchInfo = matchInfos.get(j);
                                    matchInfos.set(j, matchInfos.get(j + 1));
                                    matchInfos.set(j + 1, matchInfo);
                                }
                            }
                        }
                }
                matchTable(clubInfo);
            }

        });


        RadioButton r1 = new RadioButton("Sort by Wins");
        r1.setLayoutX(739);
        r1.setLayoutY(144);
        r1.setStyle("-fx-font-size:18 ; -fx-font-weight: bold  " );
        RadioButton r2 = new RadioButton("Sort by Goals");
        r2.setStyle("-fx-font-size:18 ; -fx-font-weight: bold " );
        r2.setLayoutX(739);
        r2.setLayoutY(175);

        r1.setToggleGroup(sortType);
        r2.setToggleGroup(sortType);

        r1.setOnAction(event ->
        {
            Integer[] clubMembers = new Integer[premierLeagueClubs.size()];
            for (int i=0;i<premierLeagueClubs.size();i++)
            {
                clubMembers[i]=premierLeagueClubs.get(i).getNumberOfWins();
            }
            for(int i=0;i<premierLeagueClubs.size();i++)
            {
                for(int j=0;j<premierLeagueClubs.size()-1-i;j++)
                {
                    if(clubMembers[j].compareTo(clubMembers[j+1]) < 0)
                    {
                        int points = clubMembers[j];
                        clubMembers[j]=clubMembers[j+1];
                        clubMembers[j+1]=points;

                        FootballClub footballClub = premierLeagueClubs.get(j);
                        premierLeagueClubs.set(j, premierLeagueClubs.get(j+1));
                        premierLeagueClubs.set(j+1, footballClub);
                    }
                }
                clubTable(clubInfo);
            }

        });

        r2.setOnAction(event ->
        {
            Integer[] clubMembers = new Integer[premierLeagueClubs.size()];
            for (int i=0;i<premierLeagueClubs.size();i++)
            {
                clubMembers[i]=premierLeagueClubs.get(i).getNumberOfGoalsScored();
            }
            for(int i=0;i<premierLeagueClubs.size();i++)
            {
                for(int j=0;j<premierLeagueClubs.size()-1-i;j++)
                {
                    if(clubMembers[j].compareTo(clubMembers[j+1]) < 0)
                    {
                        int points = clubMembers[j];
                        clubMembers[j]=clubMembers[j+1];
                        clubMembers[j+1]=points;

                        FootballClub footballClub = premierLeagueClubs.get(j);
                        premierLeagueClubs.set(j, premierLeagueClubs.get(j+1));
                        premierLeagueClubs.set(j+1, footballClub);
                    }
                }
            }
            clubTable(clubInfo);
        });

        Button btnClose =  new Button("Close");
        btnClose.setLayoutX(912);btnClose.setLayoutY(623);
        btnClose.setPrefSize(74,34);
        btnClose.setStyle("-fx-background-color: #ff6666;-fx-cursor:hand;");

        btnClose.setOnAction(event ->
        {
            stage.close();
        });

        Text txt = new Text("Premier League");
        txt.setLayoutY(48);
        txt.setLayoutX(35);
        txt.setStyle("-fx-font-weight: bold; -fx-font-size:27;-fx-text-fill: #1a1919;");


        ImageView imageView = new ImageView("ll.jpg");
        imageView.setFitHeight(707);
        imageView.setFitWidth(1220);

        clubInfo.getChildren().addAll(imageView,btnClubs,btnMatch,btnClose,txtSearch,btnSearch,btnMatchGenerate,btnSortBYDate,r1,r2,txt);
        stage.setScene(new Scene(clubInfo,1120,707.0));
        stage.showAndWait();
    }


    private void matchTable(Pane clubInfo)
    {
        TableView premierLeagueTable2 = new TableView();
        premierLeagueTable2.setLayoutX(40);
        premierLeagueTable2.setLayoutY(260);
        premierLeagueTable2.setPrefSize(1000,307.0);

        TableColumn column1 = new TableColumn("Date");
        column1.setCellValueFactory(new PropertyValueFactory("date"));
        column1.setPrefWidth(136);

        TableColumn<String, MatchInfo> column2 = new TableColumn<>("TeamOne RegNO  ");
        column2.setCellValueFactory(new PropertyValueFactory<>("teamRegNo1"));
        column2.setPrefWidth(136);

        TableColumn<String, MatchInfo> column3 = new TableColumn<>("TeamOne Name");
        column3.setCellValueFactory(new PropertyValueFactory<>("teamName1"));
        column3.setPrefWidth(136);

        TableColumn<String, MatchInfo> column4 = new TableColumn<>("TeamOne Goals");
        column4.setCellValueFactory(new PropertyValueFactory<>("numberOfGoalsScored1"));
        column4.setPrefWidth(136);

        TableColumn<String, MatchInfo> column6 = new TableColumn<>("TeamTwo RegNO");
        column6.setCellValueFactory(new PropertyValueFactory<>("teamRegNo2"));
        column6.setPrefWidth(136);

        TableColumn column7 = new TableColumn("TeamTwo Name");
        column7.setCellValueFactory(new PropertyValueFactory("teamName2"));
        column7.setPrefWidth(136);

        TableColumn<String, MatchInfo> column8 = new TableColumn<>("TeamTwo Goals");
        column8.setCellValueFactory(new PropertyValueFactory<>("numberOfGoalsScored2"));
        column8.setPrefWidth(136);

        premierLeagueTable2.getColumns().addAll(column1,column2,column3,column4,column6,column7,column8);

        for(MatchInfo match: PremierLeagueManager.matchInfos)
        {
            premierLeagueTable2.getItems().add(new MatchInfo(match.getDate(),match.getTeamRegNo1(),match.getTeamName1(),
                    match.getNumberOfGoalsScored1(),match.getNumberOfPoints1(),match.getTeamRegNo2(),
                    match.getTeamName2(),match.getNumberOfGoalsScored2(),match.getNumberOfPoints2(),match.getDay(), match.getMonth(),match.getYear()));
        }
        clubInfo.getChildren().addAll(premierLeagueTable2);
    }

    private void clubTable(Pane clubInfo)
    {
        TableView premierLeagueTable = new TableView();
        premierLeagueTable.setLayoutX(40);
        premierLeagueTable.setLayoutY(260);
        premierLeagueTable.setPrefSize(1000,307.0);
        premierLeagueTable.getItems().clear();

        TableColumn column1 = new TableColumn("Reg NO");
        column1.setCellValueFactory(new PropertyValueFactory("registrationNum"));
        column1.setPrefWidth(106);

        TableColumn<String, FootballClub> column2 = new TableColumn<>("Club Name");
        column2.setCellValueFactory(new PropertyValueFactory<>("clubName"));
        column2.setPrefWidth(106);

        TableColumn<String, FootballClub> column3 = new TableColumn<>("Played Matches");
        column3.setCellValueFactory(new PropertyValueFactory<>("numberOfMatchesPlayed"));
        column3.setPrefWidth(130);

        TableColumn<String, FootballClub> column4 = new TableColumn<>("Wins");
        column4.setCellValueFactory(new PropertyValueFactory<>("numberOfWins"));
        column4.setPrefWidth(110);

        TableColumn<String, FootballClub> column5 = new TableColumn<>("Points");
        column5.setCellValueFactory(new PropertyValueFactory<>("numberOfPoints"));
        column5.setPrefWidth(103);

        TableColumn<String, FootballClub> column6 = new TableColumn<>("Scored");
        column6.setCellValueFactory(new PropertyValueFactory<>("numberOfGoalsScored"));
        column6.setPrefWidth(103);

        TableColumn column7 = new TableColumn("Received");
        column7.setCellValueFactory(new PropertyValueFactory("numberOfGoalsReceived"));
        column7.setPrefWidth(106);

        TableColumn<String, FootballClub> column8 = new TableColumn<>("Draws");
        column8.setCellValueFactory(new PropertyValueFactory<>("numberOfDraws"));
        column8.setPrefWidth(106);

        TableColumn<String, FootballClub> column9 = new TableColumn<>("Defeats");
        column9.setCellValueFactory(new PropertyValueFactory<>("numberOfDefeats"));
        column9.setPrefWidth(106);

        premierLeagueTable.getColumns().addAll(column1,column2,column3,column4,column5,column6,column7,column8,column9);

        for(FootballClub footballClub: PremierLeagueManager.premierLeagueClubs)
        {
            premierLeagueTable.getItems().addAll(new FootballClub(footballClub.getRegistrationNum(),footballClub.getClubName(),footballClub.getNumberOfMatchesPlayed(),footballClub.getNumberOfWins(),
                    footballClub.getNumberOfPoints(),footballClub.getNumberOfGoalsScored(),footballClub.getNumberOfGoalsReceived(),footballClub.getNumberOfDraws(),footballClub.getNumberOfDefeats() ));
        }

        clubInfo.getChildren().addAll(premierLeagueTable);

    }

}
