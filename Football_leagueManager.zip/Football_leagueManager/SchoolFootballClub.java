import java.io.Serializable;
import java.util.Objects;

public class SchoolFootballClub extends FootballClub implements Serializable {
    String nameOfTheSchool;
//constructor to add school football club
    public SchoolFootballClub(String clubName, String clubLocation, int registrationNum, int contactNum, String nameOfTheSchool) {
        super(clubName, clubLocation, registrationNum, contactNum);
        this.nameOfTheSchool = nameOfTheSchool;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        SchoolFootballClub that = (SchoolFootballClub) o;
        return nameOfTheSchool.equals(that.nameOfTheSchool);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), nameOfTheSchool);
    }
}

