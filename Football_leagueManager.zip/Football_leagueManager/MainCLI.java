import javafx.application.Application;
import javafx.stage.Stage;

import java.io.EOFException;
import java.util.Scanner;

public class MainCLI extends Application {
    private static final
    Scanner inputs = new Scanner(System.in); //scanner for get inputs from user
    static FootballClub footballClub=new FootballClub();
    static FootballClubTables footballClubTables = new FootballClubTables();
    private static final PremierLeagueManager premierLeagueManager = new PremierLeagueManager();
    private static final Validations validations =new Validations();


    public static void main(String[] args)
    {
        launch();
    }
    @Override
    public void start(Stage primaryStage) throws Exception {
        try {
            premierLeagueManager.loadData();
        } catch (EOFException e)
        {
            System.out.println("NO clubs to load...");
        }

        System.out.println("\n------------------ Well Come to Premier League manager ------------------------\n ");

        menu:
        while (true)
        {
            System.out.println("\n ::::::::::::::::::::::----- Menu -----:::::::::::::::::::::::::: \n");
            //options to select
            System.out.println(" (1) - Add a new Football Club \n");
            System.out.println(" (2) - Statistics of a club\n");
            System.out.println(" (3) - Match updates\n");
            System.out.println(" (4) - View league information\n");
            System.out.println(" (G) - User interface\n ");
            System.out.println(" (D) - Delete a Football Club from the league\n");
            System.out.println(" (Q) - Exit...\n");
            System.out.print("Please select an option : ");
            //variable for store user input
            String options = inputs.next();

            switch (options) {

                case "1":
                    addNewClub();
                    break ;
                case "2":
                    statistics();
                    break;
                case "3":
                    matchUpdates();
                    break ;
                case "4":
                    sortedTable();
                    break ;
                case "G":
                case "g":
                    PremierLeague_GUI premierLeague_gui =new PremierLeague_GUI();
                    premierLeague_gui.getPremierLeagueGUI(premierLeagueManager);
                    premierLeagueManager.saveData();

                    break ;
                case "D":
                case "d":
                    deleteClub();
                    break ;
                case "Q":
                case "q":
                    System.out.println("\nExiting.................");
                    premierLeagueManager.saveData();
                    System.out.println("\n..........................Programme closed!........................");

                    break menu;

                default:
                    System.out.println("\n*********** Invalid Option Type **********");
                    break;

            }
        }

    }

    public static void addNewClub()  {

        System.out.println("\n :::::::::::::::::::::::: Add New Football Club ::::::::::::::::::::::: ");

        addMenu:
        while (true)
        {

            String clubName;
            String clubLocation;
            int contactNum;
            int regNo;

            System.out.println("\n (P) - Add to Premier League");
            System.out.println("\n (D) - Professional Development League");
            System.out.print("\n Enter an Option : ");
            String clubType = inputs.next();

            switch (clubType)
            {
                case "p":
                case "P":
                    if (PremierLeagueManager.premierLeagueClubs.size()<20)
                    {
                         regNo = validations.getRegNO(
                                 "\nPlease Enter Registration no : ",
                                 "\n****** RegisterNo already added !! Please enter new RegisterNo  ******",
                                 "\n****** Invalid Input Type !!! [Integers Only] ******");

                        clubName = validations.getAlphabetic(
                               "\nEnter Club name              : ",
                               "\n****** Invalid Input Type !!! [Letters Only] ******");

                        clubLocation = validations.getAlphabetic(
                               "\nEnter Club Location          : ",
                               "\n****** Invalid Input Type !!! [Letters Only] ******");

                        contactNum = validations.getIntegerInput(
                               "\nEnter Contact Number         : ",
                               "\n****** Invalid Input Type !!! [Integers Only] ******");
                         footballClub = new FootballClub(clubName,clubLocation,regNo,contactNum);
                       premierLeagueManager.addNewFootballCLub(footballClub);
                        break addMenu;


                    }
                    else
                    {
                        System.out.println("\n**************** Over loaded please delete a club to add a new *****************\n");

                    }
                    break addMenu;


                case "D":
                case "d":

                    System.out.println("\n(S) - School Football Club");
                    System.out.println("\n(U) - University Football Club ");
                    System.out.print("\n Enter an Option : ");
                    String options = inputs.next();
                    switch (options) {
                        case "s":
                        case "S":
                        case "u":
                        case "U":
                            regNo = validations.getRegNO(
                                    "\nPlease Enter Registration no : ",
                                    "\n****** RegisterNo already added !! Please enter new RegisterNo  ******\n",
                                    "\n****** Invalid Input Type !!! [Integers Only] ******\n");

                            clubName = validations.getAlphabetic(
                                    "\nEnter Club name              : ",
                                    "\n****** Invalid Input Type !!! [Letters Only] ******\n");

                            clubLocation = validations.getAlphabetic(
                                    "\nEnter Club Location          : ",
                                    "\n****** Invalid Input Type !!! [Letters Only] ******\n");

                            contactNum = validations.getIntegerInput(
                                    "\nEnter Contact Number         : ",
                                    "\n****** Invalid Input Type !!! [Integers Only] ******\n");

                            switch (options) {
                                case "s":
                                case "S":

                                    String schoolName = validations.getAlphabetic(
                                            "\nEntre Name Of the School : ",
                                            "\n****** Invalid Input Type !!! [Letters Only] ******\n");
                                    footballClub = new SchoolFootballClub(clubName, clubLocation, regNo, contactNum, schoolName);
                                    premierLeagueManager.addNewFootballCLub(footballClub);
                                    break addMenu;


                                case "u":
                                case "U":
                                    String universityName = validations.getAlphabetic(
                                            "\nEntre Name Of the University  : ",
                                            "\n****** Invalid Input Type !!! [Letters Only] ******\n");
                                    String facultyName = validations.getAlphabetic(
                                            "\nEntre faculty Name            : ",
                                            "\n****** Invalid Input Type !!! [Letters Only] ******\n");
                                    footballClub = new UniversityFootballClub(clubName, clubLocation, regNo, contactNum, universityName, facultyName);
                                    premierLeagueManager.addNewFootballCLub(footballClub);
                                    break addMenu;

                                default:
                                    System.out.println("\n*********** Invalid Option Type **********");
                                    break addMenu;
                            }


                        default:
                            System.out.println("\n*********** Invalid Option Type **********");
                    }    break addMenu;
            }
        }
    }

    public static void deleteClub()  {
        if(PremierLeagueManager.allClubs.size()==0 )
        {
            System.out.println("\n******************* No clubs to delete *****************\n");

        }
        else
            {
                System.out.println("\n :::::::::::::::::::::::: Delete Football Club :::::::::::::::::::::::\n ");

                footballClubTables.showAllClubs();

                int regNo = validations.getIntegerInput(
                        "\nEnter Registration number to delete : ",
                        "\n****** Invalid Input Type !!! [Integers Only] ******\n ");
                premierLeagueManager.deleteClubFromThePremierLeague(regNo);


            }
    }

    public static void statistics()  {


        if(PremierLeagueManager.premierLeagueClubs.size()==0 )
        {
            System.out.println("\n********  No any Premier League clubs to Update *********");
            System.out.println(" [*! only premier League Clubs can Update !* ] \n");
        }
        else
        {
            System.out.println("\n :::::::::::::::::::::::: Statistics Of the Clubs ::::::::::::::::::::::: \n");

            footballClubTables.showPremierLeagueClubs();
            int regNo = validations.getIntegerInput(
                    " \nRegistration number of the club : ",
                    "\n****** Invalid Input Type !!! [Integers Only] ******\n ");

            premierLeagueManager.statisticsForaSelectedClub(regNo);

        }

    }

    public static void sortedTable()  {
        if(PremierLeagueManager.premierLeagueClubs.size()==0 )
        {
            System.out.println("\n********  No any Premier League clubs to display score *********");

        }
        else {
            System.out.println("\n :::::::::::::::::::::::: Premier League Score Board :::::::::::::::::::::::: \n");
            premierLeagueManager.displayThePremierLeagueTable();
        }

    }

    public static void matchUpdates() {
        if (PremierLeagueManager.premierLeagueClubs.size()==0 )
        {
            System.out.println("\n********  No any Premier League clubs to play *********");

        }
        else
            {
                System.out.println("\n :::::::::::::::::::::::: Match Updates ::::::::::::::::::::::: ");
                footballClubTables.showPremierLeagueClubs();

                int teamOne=validations.getValidRegNO(
                        "\n Enter the Register NO of Team One : ",
                        "\n****** Club not found  ******\n",
                        "\n****** Invalid Input Type !!! [Integers Only] ******\n");
                int teamTwo=validations.getValidRegNO(
                        "\n Enter the Register NO of Team Two : ",
                        "\n****** Club not found  ******\n",
                        "\n****** Invalid Input Type !!! [Integers Only] ******\n ");
                premierLeagueManager.matchUpdate( teamOne,teamTwo);

            }
    }



}


